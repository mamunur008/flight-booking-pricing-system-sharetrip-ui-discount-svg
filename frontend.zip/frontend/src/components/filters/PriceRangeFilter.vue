<template>
  <div class="panel">
    <h3>Price Range</h3>
    <div class="panel-body">
      <p class="muted">
        Starts from ৳ {{ min }} - ৳ {{ max }} against your search. Price is
        subject to change.
      </p>
      <input type="range" style="width: 100%" :min="min" :max="max" />
      <b>BDT {{ min }} - BDT {{ max }}</b>
    </div>
  </div>
</template>

<script setup>
defineProps({
  min: { type: Number, default: 0 },
  max: { type: Number, default: 0 },
});
</script>
