<template>
  <div class="config">
    <button @click="$router.push('/')">← Flight Search</button>
    <h1>Markup, Commission & Discount Management</h1>

    <div class="row">
      <input
        v-model="cfg.airline_code"
        class="field"
        placeholder="Airline Code or blank"
      />
      <select v-model="cfg.markup_type" class="field">
        <option value="percent">percent</option>
        <option value="flat">flat</option>
      </select>
      <input
        v-model.number="cfg.markup_value"
        class="field"
        type="number"
        placeholder="Markup"
      />
      <select v-model="cfg.commission_type" class="field">
        <option value="percent">percent</option>
        <option value="flat">flat</option>
      </select>
      <input
        v-model.number="cfg.commission_value"
        class="field"
        type="number"
        placeholder="Commission"
      />
      <button class="primary" @click="save">Create</button>
    </div>

    <table>
      <thead>
        <tr>
          <th>Airline</th>
          <th>Markup</th>
          <th>Commission</th>
          <th>Active</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="c in configs" :key="c.id">
          <td>{{ c.airline_code || "All" }}</td>
          <td>{{ c.markup_value }} {{ c.markup_type }}</td>
          <td>{{ c.commission_value }} {{ c.commission_type }}</td>
          <td>{{ c.is_active }}</td>
        </tr>
      </tbody>
    </table>

    <h2>Discount Codes</h2>
    <table>
      <thead>
        <tr>
          <th>Code</th>
          <th>Type</th>
          <th>Value</th>
          <th>Route/Airline</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="d in discounts" :key="d.id">
          <td>{{ d.code }}</td>
          <td>{{ d.discount_type }}</td>
          <td>{{ d.discount_value }}</td>
          <td>{{ d.origin }} {{ d.destination }} {{ d.airline_code }}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script setup>
import { onMounted, ref } from "vue";
import { api } from "../services/api.js.back";

const configs = ref([]);
const discounts = ref([]);
const cfg = ref({
  airline_code: "",
  markup_type: "percent",
  markup_value: 8,
  commission_type: "percent",
  commission_value: 3,
  is_active: 1,
});

async function load() {
  configs.value = (await api.get("/config/lists")).data;
  discounts.value = (await api.get("/discounts")).data;
}

async function save() {
  await api.post("/config/create", cfg.value);
  await load();
}

onMounted(load);
</script>
